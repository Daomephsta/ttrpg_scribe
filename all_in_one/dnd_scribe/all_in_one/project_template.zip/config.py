from dnd_scribe.npc.race import phb

RACE_WEIGHTS = {
    '': {
        phb.HUMAN: 16,
        phb.HALFLING: 16,
        phb.HALF_ORC: 16,
        phb.DWARF: 8,
        phb.GNOME: 8,
        phb.DRAGONBORN: 4,
        phb.TIEFLING: 4,
        phb.ELF: 2,
        phb.HALF_ELF: 1,
    }
}

PARTY = ['Alice', 'Bob', 'Charlie', 'Daniell']